Instructions for Programming
Connect the USBasp programmer to your computer.

Plug the USBasp into the USB socket on your device (Rangmang socket >> GND VCC Reset Sck Miso Mosi).

Double-click on     Program Chip.bat      to start the programming process.

Wait for the programming process to complete.

Note: If you encounter any issues, check the socket, cables, and connections!